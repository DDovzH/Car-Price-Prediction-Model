import os
import io
import boto3
import json
import csv

ENDPOINT_NAME = os.environ['ENDPOINT_NAME']
runtime = boto3.client('sagemaker-runtime')


def lambda_handler(event, context):
    payload = json.loads(json.dumps(event))
    body = payload['body']

    response = runtime.invoke_endpoint(
        EndpointName=ENDPOINT_NAME,
        ContentType='application/json',
        Body=body
    )
    
    predict_bytes = response['Body'].read()
    predict = float(predict_bytes.decode('utf-8'))
    
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'price': predict
        })
    }
